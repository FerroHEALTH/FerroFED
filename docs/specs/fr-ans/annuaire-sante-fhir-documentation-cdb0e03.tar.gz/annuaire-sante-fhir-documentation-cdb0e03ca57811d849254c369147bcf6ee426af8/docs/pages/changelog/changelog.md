---
layout: default
title: Changelog
---

Le changelog  documente les modifications associées à une version de l’API FHIR Annuaire Santé. Chaque version de l'API FHIR est développé en prenant en compte la version du guide d'implémentation.

<div style="display: flex; justify-content: center;">
  <p style="background-color: #ffcccc; border:1px solid grey; padding: 10px; max-width: 790px;">
    Nous vous informons qu'à partir du 08 octobre 2026, les appels à l'API FHIR redirigeront par défaut sur la version 2. Le décommissionnement de l'API FHIR Version 1 sera effectif à partir de janvier 2027.
  </p>
</div>


**Versions disponibles de l'API FHIR Annuaire Santé**

| Version API Annuaire Santé   | Version FHIR  | Version IG | Date début | Disponible jusqu'à |
| ---                          | ---           | ---        | ---        | ---                |
| Version 1 (Beta)             | R4            | <a href="https://interop.esante.gouv.fr/ig/fhir/annuaire/0.1.0">0.1.0</a> - trial use | 5 septembre 2022  | Janvier 2027                   |
| Version 2                                 | R4            | <a href="https://interop.esante.gouv.fr/ig/fhir/annuaire">1.1.0</a>             | 28 Avril 2025               | TBD                   |

**Notes de livraison**

Une rubrique "Discussions" est disponible sur le github, permettant de consulter les évolutions correctifs et autres évolutions sur l'API FHIR V2.

Consulter l'[espace de discussions ici](https://github.com/ansforge/annuaire-sante-fhir-documentation/discussions) !